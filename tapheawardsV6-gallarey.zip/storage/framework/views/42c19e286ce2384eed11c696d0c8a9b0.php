<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo e($title); ?></title>
    <style>
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 10px; }
        h1 { text-align: center; margin-bottom: 5px; }
        p { margin: 3px 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #333; padding: 6px; text-align: left; font-size: 9px; word-wrap: break-word; }
        th { background-color: #f0f0f0; font-weight: bold; }
        .status { text-transform: capitalize; }
        .footer {
            position: fixed;
            bottom: -20px;
            left: 0px;
            right: 0px;
            height: 30px;
            text-align: center;
            line-height: 35px;
            font-size: 9px;
            color: #888;
        }
    </style>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><strong>Tarehe ya Ripoti:</strong> <?php echo e($date); ?></p>

    <?php if($filters['search'] ?? false): ?>
        <p><strong>Kichujio (Search):</strong> "<?php echo e($filters['search']); ?>"</p>
    <?php endif; ?>
    <?php if($filters['rsvp_status'] ?? false): ?>
        <p><strong>Kichujio (RSVP Status):</strong> "<?php echo e($filters['rsvp_status']); ?>"</p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th style="width: 4%;">#</th>
                <th style="width: 25%;">Guest Name</th>
                <th style="width: 20%;">Title</th>
                <th style="width: 12%;">Card Status</th>
                <th style="width: 12%;">RSVP Status</th>
                <th style="width: 15%;">Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invitations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($invitation->guest_name); ?></td>
                <td><?php echo e($invitation->guest_title ?? 'N/A'); ?></td>
                <td class="status"><?php echo e($invitation->status); ?></td>
                <td class="status"><?php echo e($invitation->rsvp_status); ?></td>
                <td><?php echo e($invitation->created_at->format('d M, Y H:i')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" style="text-align: center;">Hakuna mialiko iliyopatikana kwa vigezo hivi.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        TAPHE Awards &copy; <?php echo e(date('Y')); ?> - Ukurasa <script type="text/php">
            if (isset($pdf)) { $font = $fontMetrics->getFont("DejaVu Sans"); $pdf->page_text(500, 750, "{PAGE_NUM} / {PAGE_COUNT}", $font, 9); }
        </script>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\tapheawards\resources\views\reports\invitations_pdf.blade.php ENDPATH**/ ?>