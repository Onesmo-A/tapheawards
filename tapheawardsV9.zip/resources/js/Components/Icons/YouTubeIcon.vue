<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-6 w-6" >
    <rect width="24" height="24" rx="4" ry="4" fill="#FF0000" />
    <polygon points="9.5,7.5 16.5,12 9.5,16.5" fill="#fff" />
  </svg>
</template>
