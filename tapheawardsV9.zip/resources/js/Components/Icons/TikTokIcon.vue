<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" class="h-6 w-6">
    <path d="M223.9 79.7a74.4 74.4 0 0 1-43.6-13.9v71.1a83.7 83.7 0 1 1-83.7-83.8c3 0 6 .2 8.9.6v42.5a41.1 41.1 0 1 0 28.1 39.1V0h39a44.8 44.8 0 0 0 1.7 12.4 43.7 43.7 0 0 0 24.3 27.6 43.7 43.7 0 0 0 25.3 3.6v36.1z"/>
  </svg>
</template>
