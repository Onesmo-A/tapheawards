<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" 
    fill="none" stroke="#E1306C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" 
    class="h-6 w-6">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
    <circle cx="12" cy="12" r="5" />
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
  </svg>
</template>
