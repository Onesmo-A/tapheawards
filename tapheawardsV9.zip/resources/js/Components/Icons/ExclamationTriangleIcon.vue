<template>
  <div class="flex justify-center">
    <svg
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      stroke-width="2"
      stroke="currentColor"
      class="w-16 h-16 text-yellow-500 animate-bounce"
    >
      <path
        stroke-linecap="round"
        stroke-linejoin="round"
        d="M12 9v2m0 4h.01M10.29 3.86l-8.18 14.32A1.5 1.5 0 003.18 20h17.64a1.5 1.5 0 001.27-2.32L13.91 3.86a1.5 1.5 0 00-2.62 0z"
      />
    </svg>
  </div>
</template>
