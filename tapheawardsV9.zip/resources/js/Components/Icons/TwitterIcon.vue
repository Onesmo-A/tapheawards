<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1227" fill="currentColor" class="h-6 w-6">
    <path d="M714 502L1141 0H1041L663 455 354 0H0L453 660 0 1227H103L511 729 846 1227H1200L714 502ZM567 661L520 594 166 81H310L596 502 642 569 1005 1114H862L567 661Z"/>
  </svg>
</template>
