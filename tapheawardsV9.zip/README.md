# TAPHE Awards System

This Laravel project manages awards, voting, and nominees in a structured way.
