<script setup>
import TopBar from '@/Components/Layout/TopBar.vue';
import AppHeader from '@/Components/Layout/AppHeader.vue';
import AppFooter from '@/Components/Layout/AppFooter.vue';
</script>

<template>
    <div class="bg-gray-50 min-h-screen flex flex-col">
        <TopBar />
        <AppHeader />

        <main class="flex-grow pt-9 md:pt-[1.5rem]">
            <!--
                MAREKEBISHO:
                - pt-20: Inaongeza nafasi juu (5rem) kwa ajili ya AppHeader kwenye simu.
                - md:pt-[7.5rem]: Inaongeza nafasi juu (7.5rem) kwa ajili ya TopBar na AppHeader kwenye desktop.
            -->
            <slot />
        </main>

        <AppFooter />
    </div>
</template>