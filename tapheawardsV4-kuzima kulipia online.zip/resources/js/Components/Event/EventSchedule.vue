<template>
  <section class="flex items-center justify-center min-h-[200px] bg-gray-100 rounded-lg shadow-inner p-8 text-center">
    <h2 class="text-2xl md:text-3xl font-bold text-gray-600 animate-pulse">
       Event Schedule Coming Soon...
    </h2>
  </section>
</template>

<script setup>
// Hakuna logic kwa sasa – ni placeholder tu
</script>

<style scoped>
/* Optional extra styling */
</style>
