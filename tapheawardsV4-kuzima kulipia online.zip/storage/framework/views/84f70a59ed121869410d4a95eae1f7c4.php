<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nominee Applications</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Nominee Applications Report</h2>

    <table>
        <thead>
            <tr>
                <th>Applicant Name</th>
                <th>Category</th>
                <th>Status</th>
                <th>Payment Status</th>
                <th>Submitted On</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($application->applicant_name); ?></td>
                <td><?php echo e($application->category->name ?? 'N/A'); ?></td>
                <td><?php echo e(ucfirst(str_replace('_', ' ', $application->status))); ?></td>
                <td><?php echo e($application->transaction->status ?? 'N/A'); ?></td>
                <td><?php echo e($application->created_at->format('Y-m-d')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tapheawards\resources\views\reports\applications_pdf.blade.php ENDPATH**/ ?>