<!DOCTYPE html>
<html>
<head>
    <title>{{ $title }}</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; margin: 40px 30px 40px 30px; }
        h1 { text-align: center; margin-bottom: 5px; }
        p { margin: 3px 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; page-break-inside: auto; }
        th, td { border: 1px solid #333; padding: 5px; text-align: left; font-size: 9px; }
        th { background: #f0f0f0; }
    </style>
</head>
<body>
    <h1>{{ $title }}</h1>
    <p>Date: {{ $date }}</p>

    @if($filters['search'] ?? false)
        <p>Search filter: {{ $filters['search'] }}</p>
    @endif

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Suggested Nominee</th>
                <th>Phone</th> <!-- Hapa tumongeza Phone -->
                <th>Reason</th>
                <th>Suggester</th>
                <th>Category</th>
                <th>Submitted At</th>
            </tr>
        </thead>
        <tbody>
            @foreach($suggestions as $suggestion)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $suggestion->suggested_nominee_name }}</td>
                    <td>{{ $suggestion->suggested_nominee_phone ?? 'N/A' }}</td> <!-- Onyesha namba ya simu -->
                    <td>{{ $suggestion->reason }}</td>
                    <td>{{ $suggestion->suggester_name ?? 'N/A' }}</td>
                    <td>{{ $suggestion->category->name ?? 'N/A' }}</td>
                    <td>{{ $suggestion->created_at->format('d M, Y H:i') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
