<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nominee Applications</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Nominee Applications Report</h2>

    <table>
        <thead>
            <tr>
                <th>Applicant Name</th>
                <th>Category</th>
                <th>Status</th>
                <th>Payment Status</th>
                <th>Submitted On</th>
            </tr>
        </thead>
        <tbody>
            @foreach($applications as $application)
            <tr>
                <td>{{ $application->applicant_name }}</td>
                <td>{{ $application->category->name ?? 'N/A' }}</td>
                <td>{{ ucfirst(str_replace('_', ' ', $application->status)) }}</td>
                <td>{{ $application->transaction->status ?? 'N/A' }}</td>
                <td>{{ $application->created_at->format('Y-m-d') }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
