<?php

namespace App\Http\Controllers;

use App\Models\NomineeApplication;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WebhookController extends Controller
{
    /**
     * Pokea na shughulikia majibu ya malipo kutoka ZenoPay.
     */
    public function handleZenoPay(Request $request)
    {
        // Log ya awali kabisa kuthibitisha ombi limefika, na tunaweka payload yote
        Log::channel('stack')->info('ZenoPay Webhook Endpoint Hit.', [
            'ip' => $request->ip(),
            'headers' => $request->headers->all(), // Log headers zote kwa ajili ya uchunguzi
            'payload' => $request->all()
        ]);

        try {
            // ================== USALAMA WA WEBHOOK (HYBRID: API Key + IP Whitelist) ==================
            $isAuthenticated = false;
            $authMethod = 'None';

            // 1. Jaribu kuthibitisha kwa kutumia API Key (Njia Bora na Salama Zaidi)
            $zenoApiKey = config('services.zenopay.key');
            $receivedApiKey = $request->header('x-api-key');

            if ($receivedApiKey && hash_equals((string) $zenoApiKey, (string) $receivedApiKey)) {
                $isAuthenticated = true;
                $authMethod = 'API Key';
            }

            // 2. Kama API Key imefeli, jaribu kuthibitisha kwa IP (Njia ya Ziada)
            if (!$isAuthenticated) {
                $allowedIps = config('services.zenopay.ips');
                if ($allowedIps && in_array($request->ip(), explode(',', $allowedIps))) {
                    $isAuthenticated = true;
                    $authMethod = 'IP Whitelist';
                    // Log onyo muhimu: Ombi limeruhusiwa kwa IP, lakini API key haikuwepo/sahihi.
                    Log::warning('ZenoPay Webhook: Authentication via IP Whitelist. API Key was missing or invalid.', [
                        'ip' => $request->ip(),
                        'received_key' => $receivedApiKey, // Log key iliyopokelewa kwa uchunguzi
                    ]);
                }
            }

            // 3. Kama njia zote zimeshindikana, kataa ombi
            if (!$isAuthenticated) {
                Log::critical('ZenoPay Webhook: UNAUTHORIZED ATTEMPT - Both API Key and IP Whitelist checks failed.', [
                    'ip' => $request->ip(),
                    'received_key' => $receivedApiKey,
                ]);
                return response()->json(['status' => 'error', 'message' => 'Unauthorized'], 403);
            }

            $payload = $request->all();
            Log::info('ZenoPay Webhook Received and Authenticated via ' . $authMethod, $payload);

            $orderId = $payload['order_id'] ?? null;
            $status = $payload['payment_status'] ?? null;

            if (!$orderId || !$status) {
                Log::warning('ZenoPay Webhook: Missing required parameters.', ['payload' => $payload]);
                return response()->json(['status' => 'error', 'message' => 'Missing parameters'], 400);
            }

            // 2. Pata transaction yetu kwa kutumia order_id
            $transaction = Transaction::where('order_id', $orderId)->first();

            if (!$transaction) {
                Log::error('ZenoPay Webhook: Transaction not found.', ['order_id' => $orderId]);
                return response()->json(['status' => 'success', 'message' => 'Transaction not found but acknowledged']);
            }

            // 3. Zuia kusasisha transaction ambayo haiko 'pending'
            // BORESHO: Tumia constant badala ya 'hardcoded string'
            if ($transaction->status !== Transaction::STATUS_PENDING) {
                Log::info('ZenoPay Webhook: Transaction already processed, ignoring.', ['order_id' => $orderId, 'current_status' => $transaction->status]);
                return response()->json(['status' => 'success', 'message' => 'Already processed']);
            }

            // 4. Tumia DB Transaction kuhakikisha data inakuwa sahihi (atomicity)
            DB::transaction(function () use ($transaction, $status, $payload) {
                // BORESHO: Tumia constants kwa usahihi na usalama
                if ($status === 'COMPLETED') {
                    $transaction->update([
                        'status' => Transaction::STATUS_COMPLETED,
                        'gateway_reference' => $payload['reference'] ?? ($payload['transid'] ?? null),
                        'payment_method' => $payload['channel'] ?? null,
                        'notes' => 'Webhook: Payment completed successfully.',
                    ]);
                    $transaction->payable?->update(['status' => NomineeApplication::STATUS_PENDING_REVIEW]);
                    Log::info('ZenoPay Webhook: Transaction status updated to COMPLETED.', ['order_id' => $transaction->order_id]);
                } elseif ($status === 'FAILED') {
                    $transaction->update([
                        'status' => Transaction::STATUS_FAILED,
                        'notes' => 'Webhook: Payment failed. Reason: ' . ($payload['message'] ?? 'Unknown'),
                    ]);
                    $transaction->payable?->update(['status' => NomineeApplication::STATUS_PAYMENT_FAILED]);
                    Log::info('ZenoPay Webhook: Transaction status updated to FAILED.', ['order_id' => $transaction->order_id]);
                }
            });

            // 5. Jibu ZenoPay kwamba umepokea taarifa yao
            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::critical('ZenoPay Webhook: CRITICAL ERROR during processing.', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'payload' => $request->all(),
            ]);
            return response()->json(['status' => 'error', 'message' => 'Internal Server Error'], 500);
        }
    }
}