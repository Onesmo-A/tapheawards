<?php

namespace App\Http\Controllers\Admin;
use App\Models\NomineeApplication;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;
use Inertia\Inertia;

class NomineeApplicationController extends Controller
{
    /**
     * Onyesha orodha ya maombi yote.
     */
    public function index(Request $request)
    {
        $applications = NomineeApplication::query()
            ->with(['user:id,name', 'category:id,name', 'transaction'])
            ->when($request->input('search'), function ($query, $search) {
                $query->where('applicant_name', 'like', "%{$search}%")
                    ->orWhereHas('user', fn ($q) => $q->where('name', 'like', "%{$search}%"))
                    ->orWhereHas('category', fn($q) => $q->where('name', 'like', "%{$search}%"));
            })
            ->when($request->input('status'), function ($query, $status) {
                $query->where('status', $status);
            })
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return Inertia::render('Admin/Applications/Index', [
            'applications' => $applications,
            'filters' => $request->only(['search', 'status']),
        ]);
    }

    /**
     * Onyesha taarifa za ombi moja.
     */
    public function show(NomineeApplication $application)
    {
        $application->load(['user', 'category', 'transaction']);
        return Inertia::render('Admin/Applications/Show', [
            'application' => $application,
        ]);
    }

    /**
     * Sasisha status ya ombi (Kubali/Kataa).
     */
    public function update(Request $request, NomineeApplication $application)
    {
        $validated = $request->validate([
            'action' => 'required|in:approve,reject',
            'rejection_reason' => 'nullable|string|required_if:action,reject',
        ]);

        if ($validated['action'] === 'approve') {
            // 1. Badilisha status ya ombi
            $application->update([
                'status' => 'approved',
                'reviewed_by' => auth()->id(),
                'reviewed_at' => now(),
            ]);

            // 2. Andaa data za pre-fill
            $prefillData = [
                'name' => $application->applicant_name,
                'bio' => $application->bio,
                'category_id' => $application->category_id,
                'image_url' => $application->photo_url,
                'source_application_id' => $application->id, // Tuma ID ya ombi kwa ajili ya reference
            ];

            // Ongeza social links kwenye pre-fill data
            // Use the direct properties from the model
            $prefillData['social_links'] = [
                'facebook' => $application->facebook_url,
                'instagram' => $application->instagram_url,
                // Add other social links here if they exist as columns
            ];

            return redirect()->route('admin.nominees.create')->with('prefill', $prefillData);
        }

        if ($validated['action'] === 'reject') {
            $application->update([
                'status' => 'rejected',
                'rejection_reason' => $validated['rejection_reason'],
                'reviewed_by' => auth()->id(),
                'reviewed_at' => now(),
            ]);
            return redirect()->route('admin.applications.index')->with('success', 'Ombi limekataliwa kikamilifu.');
        }

        return redirect()->route('admin.applications.index')->with('error', 'Kitendo hakijulikani.');
    }

    /**
     * Export applications data to a PDF file.
     */
    public function exportPdf(Request $request)
    {
        $applications = NomineeApplication::query()
            ->with(['user:id,name', 'category:id,name', 'transaction:status'])
            ->when($request->input('search'), function ($query, $search) {
                $query->where('applicant_name', 'like', "%{$search}%")
                    ->orWhereHas('user', fn ($q) => $q->where('name', 'like', "%{$search}%"))
                    ->orWhereHas('category', fn($q) => $q->where('name', 'like', "%{$search}%"));
            })
            ->when($request->input('status'), function ($query, $status) {
                $query->where('status', $status);
            })
            ->latest()
            ->get();

        $data = [
            'title' => 'Nominee Applications Report',
            'date' => now()->setTimezone('Africa/Nairobi')->format('d M, Y H:i'),
            'applications' => $applications,
            'filters' => $request->only(['search', 'status']),
        ];

        $pdf = PDF::loadView('reports.applications_pdf', $data);
        $slug = 'applications-report-' . now()->format('Y-m-d');

        return $pdf->download($slug . '.pdf');
    }
}