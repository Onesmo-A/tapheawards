<script setup>
import DefaultLayout from '@/Layouts/DefaultLayout.vue';
import { Head } from '@inertiajs/vue3';
</script>

<template>
    <Head title="Past Award Winners" />

    <DefaultLayout>
        <div class="bg-black text-white min-h-screen">
            <header class="bg-gradient-to-b from-gray-900 via-black to-black py-24 sm:py-32">
                <div class="mx-auto max-w-7xl px-6 lg:px-8 text-center">
                    <h1 class="text-4xl font-bold tracking-tight sm:text-6xl bg-gradient-to-r from-yellow-300 via-gold-500 to-yellow-300 bg-clip-text text-transparent">
                        Past Award Winners
                    </h1>
                </div>
            </header>
        </div>
    </DefaultLayout>
</template>