<?php

namespace App\Http\Controllers;

use App\Models\NomineeApplication;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WebhookController extends Controller
{
    /**
     * Pokea na shughulikia majibu ya malipo kutoka ZenoPay.
     */
    public function handleZenoPay(Request $request)
    {
        // Log ya awali kabisa kuthibitisha ombi limefika, na tunaweka payload yote
        Log::channel('stack')->info('ZenoPay Webhook Endpoint Hit.', [
            'ip' => $request->ip(),
            'headers' => $request->headers->all(), // Log headers zote kwa ajili ya uchunguzi
            'payload' => $request->all()
        ]);

        try {
            // ================== USALAMA WA WEBHOOK (IP Whitelisting) ==================
            // Hii ni njia ya usalama kuhakikisha maombi yanatoka ZenoPay/Selcom pekee.
            // Suluhisho bora zaidi ni ZenoPay kutuma 'x-api-key' au signature ya webhook.
            $allowedIps = config('services.zenopay.ips');
            if ($allowedIps && !in_array($request->ip(), explode(',', $allowedIps))) {
                Log::critical('ZenoPay Webhook: UNAUTHORIZED ATTEMPT - IP not whitelisted.', [
                    'ip' => $request->ip(),
                    'allowed_ips' => $allowedIps,
                ]);
                return response()->json(['status' => 'error', 'message' => 'Unauthorized'], 403);
            }

            $payload = $request->all();
            Log::info('ZenoPay Webhook Received and Authenticated:', $payload);

            $orderId = $payload['order_id'] ?? null;
            $status = $payload['payment_status'] ?? null;

            if (!$orderId || !$status) {
                Log::warning('ZenoPay Webhook: Missing required parameters.', ['payload' => $payload]);
                return response()->json(['status' => 'error', 'message' => 'Missing parameters'], 400);
            }

            // 2. Pata transaction yetu kwa kutumia order_id
            $transaction = Transaction::where('order_id', $orderId)->first();

            if (!$transaction) {
                Log::error('ZenoPay Webhook: Transaction not found.', ['order_id' => $orderId]);
                return response()->json(['status' => 'success', 'message' => 'Transaction not found but acknowledged']);
            }

            // 3. Zuia kusasisha transaction ambayo haiko 'pending'
            // BORESHO: Tumia constant badala ya 'hardcoded string'
            if ($transaction->status !== Transaction::STATUS_PENDING) {
                Log::info('ZenoPay Webhook: Transaction already processed, ignoring.', ['order_id' => $orderId, 'current_status' => $transaction->status]);
                return response()->json(['status' => 'success', 'message' => 'Already processed']);
            }

            // 4. Tumia DB Transaction kuhakikisha data inakuwa sahihi (atomicity)
            DB::transaction(function () use ($transaction, $status, $payload) {
                // BORESHO: Tumia constants kwa usahihi na usalama
                if ($status === 'COMPLETED') {
                    $transaction->update([
                        'status' => Transaction::STATUS_COMPLETED,
                        'gateway_reference' => $payload['reference'] ?? ($payload['transid'] ?? null),
                        'payment_method' => $payload['channel'] ?? null,
                        'notes' => 'Webhook: Payment completed successfully.',
                    ]);
                    $transaction->payable?->update(['status' => NomineeApplication::STATUS_PENDING_REVIEW]);
                    Log::info('ZenoPay Webhook: Transaction status updated to COMPLETED.', ['order_id' => $transaction->order_id]);
                } elseif ($status === 'FAILED') {
                    $transaction->update([
                        'status' => Transaction::STATUS_FAILED,
                        'notes' => 'Webhook: Payment failed. Reason: ' . ($payload['message'] ?? 'Unknown'),
                    ]);
                    $transaction->payable?->update(['status' => NomineeApplication::STATUS_PAYMENT_FAILED]);
                    Log::info('ZenoPay Webhook: Transaction status updated to FAILED.', ['order_id' => $transaction->order_id]);
                }
            });

            // 5. Jibu ZenoPay kwamba umepokea taarifa yao
            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::critical('ZenoPay Webhook: CRITICAL ERROR during processing.', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'payload' => $request->all(),
            ]);
            return response()->json(['status' => 'error', 'message' => 'Internal Server Error'], 500);
        }
    }
}