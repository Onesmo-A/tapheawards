<?php

namespace App\Http\Controllers;

use App\Models\Suggestion;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;

class SuggestionController extends Controller
{
    /**
     * Hifadhi pendekezo jipya kutoka kwa mtumiaji.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'suggested_nominee_name' => 'required|string|max:255',
            'suggested_nominee_phone' => 'nullable|string|max:20',
            'suggested_nominee_workplace' => 'nullable|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'reason' => 'required|string|min:20',
            'suggester_name' => 'nullable|string|max:255',
            'suggester_email' => 'nullable|email|max:255',
        ], [
            'suggested_nominee_name.required' => 'Jina la anayependekezwa linahitajika.',
            'category_id.required' => 'Tafadhali chagua kategoria.',
            'reason.required' => 'Tafadhali eleza sababu za kumpendekeza.',
            'reason.min' => 'Maelezo ya sababu yanapaswa kuwa na angalau herufi 20.',
        ]);

        Suggestion::create($validated);

        return back()->with('success', 'Asante! Pendekezo lako limepokelewa na litapitiwa na timu yetu.');
    }
}