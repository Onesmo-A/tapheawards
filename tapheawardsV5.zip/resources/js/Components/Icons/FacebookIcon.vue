<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" 
    fill="none" stroke="#1877F2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" 
    class="h-6 w-6">
    <path d="M18 2h-3a4 4 0 0 0-4 4v3H7v4h4v8h4v-8h3l1-4h-4V6a1 1 0 0 1 1-1h3z"/>
  </svg>
</template>
